local l = (bl and 1) or -1

if I:isEnchanted(item) then 
particleManager:addParticle(
    particles,
    false,
    0 * l , 0.3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    2.5,
    Texture:of("minecraft", "textures/particle/swordglow.png"),
    "ITEM",
    hand,
    "SPAWN",
    "ADDITIVE",
    0,
    200
)

end 